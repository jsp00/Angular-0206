import { Component, OnInit } from '@angular/core';
import {Employee} from "../model/Employee.model";

@Component({
  selector: 'app-edit-employee-template',
  templateUrl: './edit-employee-template.component.html',
  styleUrls: ['./edit-employee-template.component.css']
})
export class EditEmployeeTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  departments = [

    { id: 1, name: "Payroll" },

    { id: 2, name: "Internal" },

    { id: 3, name: "HR" }
  ];

  employees: Employee =
    {
      id: 1,
      name: "Ramkumar",
      salary: 20000,
      permanent: true,
      department: this.departments[0],
      skill: [
        {
          id: 1,
          name: 'C#'
        }
      ],
      dateOfBirth: new Date()
    };

    onSubmit(data: any){
      console.warn(data);
    }
}
