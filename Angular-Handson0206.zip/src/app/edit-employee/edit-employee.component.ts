import { Component, OnInit } from '@angular/core';
import {Employee} from "../model/Employee.model";
import {FormControl, FormGroup, Validators} from "@angular/forms";



@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  departments = [

    { id: 1, name: "Payroll" },

    { id: 2, name: "Internal" },

    { id: 3, name: "HR" }
  ];

  employees: Employee =
    {
      id: 1,
      name: "Ramkumar",
      salary: 20000,
      permanent: true,
      department: this.departments[0],
      skill: [
        {
          id: 1,
          name: 'C#'
        }
      ],
      dateOfBirth: new Date()
    };

    empForm = new FormGroup({
      name : new FormControl(this.employees.name, [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)
      ]),
      salary : new FormControl(this.employees.salary, [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)
      ]),
      permanent : new FormControl(this.employees.permanent, [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)
      ]),
      department : new FormControl(this.employees.department, [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)
      ]),
    })

  onSubmit(data: any){
    console.warn(data);
  }

  get name(){
    return this.empForm.get('name');
  }

}
