import {ComponentFixture, TestBed} from '@angular/core/testing';

import {EmployeeComponentComponent} from './employee-component.component';
import {IEmployee} from "./Employee.model";

describe('EmployeeComponentComponent', () => {
  let component: EmployeeComponentComponent;
  let fixture: ComponentFixture<EmployeeComponentComponent>;
  let h1: HTMLElement;
  let employee: IEmployee;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmployeeComponentComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a title Employee Information', function () {
    const fixture = TestBed.createComponent(EmployeeComponentComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('Employee Information');
  });

  it('should have a title Employee Information in h1 tag', function () {
    fixture.detectChanges();
    h1 = fixture.nativeElement.querySelector('h1');
    expect(h1.textContent).toContain(component.title);
  });


  it("should define DisplayId", function () {
    expect(component.DisplayId).toBeTruthy();
  });
  it("should define DisplayName", function () {
    expect(component.DisplayName).toBeDefined();
  });
  it("should define DisplaySalary", function () {
    expect(component.DisplaySalary).toBeDefined();
  });
  it("should define DisplayPermanentOrNot", function () {
    expect(component.DisplayPermanentOrNot).toBeDefined();
  });


  it('should employee id greater than or equal to 1000', function () {

    expect(component.DisplayId()).toBeGreaterThanOrEqual(1000);
  });
  it('should employee name is not blank', function () {
    const app = fixture.debugElement.nativeElement;
    console.log(app.querySelectorAll("h2"));
    expect(component.DisplayName()).toBeTruthy();
  });
  it('should employee salary greater than or equal to 1000', function () {

    const app = fixture.debugElement.nativeElement;
    console.log(app.querySelector("h2"));
    expect(component.DisplaySalary()).toBeGreaterThanOrEqual(3000);
  });
});
