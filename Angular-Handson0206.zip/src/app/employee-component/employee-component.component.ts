import {Component, OnInit} from '@angular/core';
import {IEmployee} from "./Employee.model";

@Component({
  selector: 'app-employee-component',
  templateUrl: './employee-component.component.html',
  styleUrls: ['./employee-component.component.css']
})
export class EmployeeComponentComponent implements OnInit {

  title = 'Employee Information';

  constructor() {
  }

  ngOnInit(): void {
  }

  employee: IEmployee =
    {
      id: 3001,
      name: "John",
      salary: 20000,
      permanent: false
    };

  DisplayId() {
    return this.employee.id;
  }

  DisplayName() {
    return this.employee.name;
  }

  DisplaySalary() {
    return this.employee.salary;
  }

  DisplayPermanentOrNot() {
    return this.employee.permanent;
  }

}
